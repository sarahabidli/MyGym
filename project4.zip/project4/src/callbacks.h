#include <gtk/gtk.h>



void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked    (GtkWidget   *objet_graphique, gpointer user_data);

void
on_button7_clicked   (GtkWidget       *objet_graphique,
  gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked    (GtkWidget       *objet, gpointer         user_data);


