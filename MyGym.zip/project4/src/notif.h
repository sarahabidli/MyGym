#include <gtk/gtk.h>

void afficher_notif(GtkWidget *liste);
void ajouter_notif(char notif[]);